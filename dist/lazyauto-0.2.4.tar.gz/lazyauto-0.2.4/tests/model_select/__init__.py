# -*- coding: utf-8 -*-
"""
Created on Thu Aug  3 16:24:18 2023

@author: kaan1
"""


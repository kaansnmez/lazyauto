# -*- coding: utf-8 -*-
"""
Created on Thu Aug  3 16:49:20 2023

@author: kaan1
"""


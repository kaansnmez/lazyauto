"""Top-level package for lazyauto."""

__author__ = """Ahmet Kaan Sonmez"""
__email__ = 'kaan.sonmez97@gmail.com'
__version__ = '0.2.2'

from .Eda import *

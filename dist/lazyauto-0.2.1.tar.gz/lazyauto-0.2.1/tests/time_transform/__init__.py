# -*- coding: utf-8 -*-
"""
Created on Thu Aug  3 17:00:07 2023

@author: kaan1
"""


# -*- coding: utf-8 -*-
"""
Created on Wed Jul 26 14:06:36 2023

@author: kaan1
"""


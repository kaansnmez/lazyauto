# -*- coding: utf-8 -*-
"""
Created on Thu Aug  3 15:44:00 2023

@author: kaan1
"""


=====
Usage
=====

To use lazyauto in a project::

    import lazyauto
